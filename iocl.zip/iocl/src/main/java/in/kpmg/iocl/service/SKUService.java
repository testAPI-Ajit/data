package in.kpmg.iocl.service;

import in.kpmg.iocl.model.SKUModel;
import in.kpmg.iocl.repository.SKURepository;
import in.kpmg.iocl.skuapi.SkuAltConversion;
import in.kpmg.iocl.skuapi.SkuAltConversionRequest;
import in.kpmg.iocl.skuapi.SkuAltConversionResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.*;

@Service
public class SKUService {

    @Autowired
    SKURepository skuRepository;

    public SkuAltConversionResponse getSkuresponse(@RequestBody SkuAltConversionRequest req) {

        String numConversion = req.getNumeratorConversion();
        String denConversion = req.getDenominatorConversion();
        String alt_from_uom = req.getAlternateFromUom();
        String alt_to_UOM = req.getAlternateToUom();
        String materialCode = req.getMaterialCode();

        SkuAltConversionResponse skuAltConversionResponse = new SkuAltConversionResponse();
        skuAltConversionResponse.setIsSuccess(false);

        List<SkuAltConversion> skuAltConversionDetails = new ArrayList<>();

        if(materialCode!=null && alt_from_uom !=null & alt_from_uom !=null && numConversion !=null && denConversion !=null)
        {
            try {
                List<SKUModel> skuDetails = skuRepository.getSKUData(numConversion,denConversion,alt_from_uom,alt_to_UOM,materialCode);
                    for(SKUModel skuData:skuDetails)
                    {
                        SkuAltConversion sku_altConversion = new SkuAltConversion();

                        sku_altConversion.setNumeratorConversion(sku_altConversion.getNumeratorConversion());
                        sku_altConversion.setDenominatorConversion(sku_altConversion.getDenominatorConversion());
                        sku_altConversion.setAlternateFromUOM(sku_altConversion.getAlternateFromUOM());
                        sku_altConversion.setAlternateToUOM(sku_altConversion.getAlternateToUOM());
                        sku_altConversion.setMaterialCode(sku_altConversion.getMaterialCode());
                    }

                    if (materialCode == null) {
                    skuAltConversionResponse.setIsSuccess(false);
                    skuAltConversionResponse.setMessage("Material Code is empty");
                    }

            }catch(Exception ex){
                System.out.println( "Error in service layer.Description of error is: "+ ex.getMessage());
            }
        }return skuAltConversionResponse;
    }
 }
